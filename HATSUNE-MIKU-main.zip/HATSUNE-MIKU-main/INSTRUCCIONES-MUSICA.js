
const MUSICA_URL = 'https://litter.catbox.moe/ae5f27n13of6sbtb.mp3'

console.log('🎵 SISTEMA DE MÚSICA SIMPLIFICADO')
console.log('📁 Solo necesitas cambiar una línea:')
console.log(`🔗 URL actual: ${MUSICA_URL}`)
console.log('')
console.log('✅ Para cambiar la música:')
console.log('1. Abre index.js')
console.log('2. Busca: const MUSICA_URL =')
console.log('3. Cambia la URL por tu música')
console.log('4. Guarda y reinicia el bot')
console.log('')
console.log('🎯 Configuración completada!')

